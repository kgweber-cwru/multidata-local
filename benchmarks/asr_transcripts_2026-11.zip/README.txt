Transcripts from the speech-to-text benchmark (November 2026)
=======================================================

These are the transcripts behind "ASR benchmark: first findings (November
2026)". They come from 5 simulated encounters in our sim center. Each
folder is one recording and holds:

  00 Human (gold).txt   what our annotators heard, transcribed by hand and
                        reviewed. The engines are scored against this.
  01 ... 08             what each engine produced from the same audio, best
                        overall score first.

The engines, in file order:
  01 AssemblyAI                     AssemblyAI universal-3-5-pro (cloud)
  02 Gemini                         Google Gemini 3.5 Transcribe (cloud)
  03 ElevenLabs scribe_v3           ElevenLabs scribe_v3 (cloud)
  04 ElevenLabs scribe_v2_medical   ElevenLabs scribe_v2_medical, the model sold with a BAA (cloud)
  05 Google Chirp 3                 Google Chirp 3 (cloud)
  06 faster-whisper                 faster-whisper medium (local)
  07 WhisperX                       WhisperX large-v3 (local)
  08 WhisperX disfluent             WhisperX large-v3, set to keep ums and uhs (local)

How to read them
----------------
Each line is one turn: the time into the recording, who spoke, and what was
said. In the human transcript the speakers are named by role (Learner,
Patient, Preceptor, Announcement). The engines don't know who anyone is;
they only split the voices apart and number them, so "Speaker 1" in one
file is not the same person as "Speaker 1" in another. Working out which
number is the learner and which the patient is part of reading them.

Long silences (physical exam, note writing) show only as jumps in the time.

Each engine file starts with two scores for that recording:
  - Words wrong: the share of the human transcript's words the engine got
    wrong, left out, or added. 15% means roughly 1 word in 7.
  - Words wrong or with the wrong speaker: the same, but also counting words
    the engine gave to the wrong person.

Names
-----
Names have been replaced with tags such as [LEARNER_NAME], [PATIENT_NAME]
and [PRECEPTOR_NAME]. [PATIENT_NAME] stands for the actor's own name; the
character's name in the scenario is fictional and is left in. The
replacement is automatic, so the odd nickname or misspelled name gets
through.

Marks in the human transcript
-----------------------------
  um, uh           hesitations, written as said
  mm-hmm, uh-huh   "yes"; uh-uh and mm-mm mean "no"
  wor-             a word cut off part way
  so:              a drawn-out sound
  [unintelligible] nothing could be made out; [unintelligible: pressure?]
                   is the annotator's best guess
  [laughs] etc.    sounds other than words

Please keep these within the team: they record learners' performance.
